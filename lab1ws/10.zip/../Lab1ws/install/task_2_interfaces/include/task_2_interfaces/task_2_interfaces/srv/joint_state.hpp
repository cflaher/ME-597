// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef TASK_2_INTERFACES__SRV__JOINT_STATE_HPP_
#define TASK_2_INTERFACES__SRV__JOINT_STATE_HPP_

#include "task_2_interfaces/srv/detail/joint_state__struct.hpp"
#include "task_2_interfaces/srv/detail/joint_state__builder.hpp"
#include "task_2_interfaces/srv/detail/joint_state__traits.hpp"
#include "task_2_interfaces/srv/detail/joint_state__type_support.hpp"

#endif  // TASK_2_INTERFACES__SRV__JOINT_STATE_HPP_
